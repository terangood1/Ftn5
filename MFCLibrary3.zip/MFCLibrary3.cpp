﻿// MFCLibrary3.cpp : DLL의 초기화 루틴을 정의합니다.
//

#include "pch.h"
#include "framework.h"
#include "test1.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif

int AFX_EXT_CLASS CMath::Test(int a, int b) {
	return a - b;
}
