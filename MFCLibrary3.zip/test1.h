#pragma once
#include "pch.h"
class AFX_EXT_CLASS CMath {
public:
	int Test(int a, int b);

};